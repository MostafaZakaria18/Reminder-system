package com.example.signupauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignUpAuthApplication {
    public static void main(String[] args) {
        SpringApplication.run(SignUpAuthApplication.class, args);
    }
} 